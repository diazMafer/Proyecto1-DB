// Create the chart
Highcharts.chart('container5', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Cantidad de vuelos a los 10 estados más poblados. 2017-2018'
    },
    subtitle: {
        text: 'Click a las columnas para ver la cantidad de vuelos por estado más poblado.'
    },
    credits: {
        enabled: false
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'Total de vuelos'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.0f}'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f}</b> of total<br/>'
    },

    "series": [
        {
            "name": "Aerolíneas",
            "colorByPoint": true,
            "data": [
                {
                    "name": "Southwest",
                    "y": 2588372,
                    "drilldown": "Southwest"
                },
                {
                    "name": "Delta",
                    "y": 1811590,
                    "drilldown": "Delta"
                },
                {
                    "name": "American",
                    "y": 1748036,
                    "drilldown": "American"
                },
                {
                    "name": "SkyWest",
                    "y": 1427134,
                    "drilldown": "SkyWest"
                },
                {
                    "name": "United",
                    "y": 1163009,
                    "drilldown": "United"
                },
                {
                    "name": "JetBlue",
                    "y": 581778,
                    "drilldown": "JetBlue"
                },
                {
                    "name": "ExpressJet",
                    "y": 533340,
                    "drilldown": "ExpressJet"
                },
                {
                    "name": "Alaska",
                    "y": 412033,
                    "drilldown": "Alaska"
                },
                {
                    "name": "Spirit",
                    "y": 319422,
                    "drilldown": "Spirit"
                },
                {
                    "name": "Republic",
                    "y": 290451,
                    "drilldown": "Republic"
                },
                {
                    "name": "Envoy",
                    "y": 270405,
                    "drilldown": "Envoy"
                },
                {
                    "name": "PSA",
                    "y": 255396,
                    "drilldown": "PSA"
                },
                {
                    "name": "Endeavor",
                    "y": 225227,
                    "drilldown": "Endeavor"
                },
                {
                    "name": "Frontier",
                    "y": 214181,
                    "drilldown": "Frontier"
                },
                {
                    "name": "Mesa",
                    "y": 196562,
                    "drilldown": "Mesa"
                },
                {
                    "name": "Hawaiian",
                    "y": 157488,
                    "drilldown": "Hawaiian"
                },
                {
                    "name": "Virgin",
                    "y": 89328,
                    "drilldown": "Virgin"
                }
            ]
        }
    ],
    "drilldown": {
        "series": [
            {
                "name": "Southwest",
                "id": "Southwest",
                "data": [
                    [
                        "Texas",
                        331169
                    ],
                    [
                        "California",
                        464969
                    ],
                    [
                        "Florida",
                        216914
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        19342
                    ],
                    [
                        "New York",
                        54337
                    ],
                    [
                        "Colorado",
                        132526
                    ],
                    [
                        "Illinois",
                        159992
                    ],
                    [
                        "North Carolina",
                        25762
                    ],
                    [
                        "Virginia",
                        41142
                    ]
                ]
            },
            {
                "name": "Delta",
                "id": "Delta",
                "data": [
                    [
                        "Texas",
                        47988
                    ],
                    [
                        "California",
                        127628
                    ],
                    [
                        "Florida",
                        158706
                    ],
                    [
                        "Alaska",
                        5122
                    ],
                    [
                        "Michigan",
                        117602
                    ],
                    [
                        "New York",
                        116833
                    ],
                    [
                        "Colorado",
                        22323
                    ],
                    [
                        "Illinois",
                        21020
                    ],
                    [
                        "North Carolina",
                        33997
                    ],
                    [
                        "Virginia",
                        36818
                    ]
                ]
            },
            {
                "name": "American",
                "id": "American",
                "data": [
                    [
                        "Texas",
                        323815
                    ],
                    [
                        "California",
                        158603
                    ],
                    [
                        "Florida",
                        197394
                    ],
                    [
                        "Alaska",
                        536
                    ],
                    [
                        "Michigan",
                        11861
                    ],
                    [
                        "New York",
                        81659
                    ],
                    [
                        "Colorado",
                        26073
                    ],
                    [
                        "Illinois",
                        123171
                    ],
                    [
                        "North Carolina",
                        207530
                    ],
                    [
                        "Virginia",
                        61256
                    ]
                ]
            },
            {
                "name": "SkyWest",
                "id": "SkyWest",
                "data": [
                    [
                        "Texas",
                        44173
                    ],
                    [
                        "California",
                        150601
                    ],
                    [
                        "Florida",
                        2148
                    ],
                    [
                        "Alaska",
                        374
                    ],
                    [
                        "Michigan",
                        109150
                    ],
                    [
                        "New York",
                        23445
                    ],
                    [
                        "Colorado",
                        120623
                    ],
                    [
                        "Illinois",
                        164143
                    ],
                    [
                        "North Carolina",
                        14172
                    ],
                    [
                        "Virginia",
                        14169
                    ]
                ]
            },
            {
                "name": "United",
                "id": "United",
                "data": [
                    [
                        "Texas",
                        150601
                    ],
                    [
                        "California",
                        216921
                    ],
                    [
                        "Florida",
                        71881
                    ],
                    [
                        "Alaska",
                        1987
                    ],
                    [
                        "Michigan",
                        4755
                    ],
                    [
                        "New York",
                        21426
                    ],
                    [
                        "Colorado",
                        122110
                    ],
                    [
                        "Illinois",
                        145456
                    ],
                    [
                        "North Carolina",
                        10353
                    ],
                    [
                        "Virginia",
                        58729
                    ]
                ]
            },
            {
                "name": "JetBlue",
                "id": "JetBlue",
                "data": [
                    [
                        "Texas",
                        7160
                    ],
                    [
                        "California",
                        61354
                    ],
                    [
                        "Florida",
                        129253
                    ],
                    [
                        "Alaska",
                        424
                    ],
                    [
                        "Michigan",
                        2722
                    ],
                    [
                        "New York",
                        119592
                    ],
                    [
                        "Colorado",
                        2220
                    ],
                    [
                        "Illinois",
                        4808
                    ],
                    [
                        "North Carolina",
                        8980
                    ],
                    [
                        "Virginia",
                        29663
                    ]
                ]
            },
            {
                "name": "ExpressJet",
                "id": "ExpressJet",
                "data": [
                    [
                        "Texas",
                        127747
                    ],
                    [
                        "California",
                        0
                    ],
                    [
                        "Florida",
                        10710
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        13641
                    ],
                    [
                        "New York",
                        29996
                    ],
                    [
                        "Colorado",
                        954
                    ],
                    [
                        "Illinois",
                        36732
                    ],
                    [
                        "North Carolina",
                        13900
                    ],
                    [
                        "Virginia",
                        21615
                    ]
                ]
            },
            {
                "name": "Alaska",
                "id": "Alaska",
                "data": [
                    [
                        "Texas",
                        8062
                    ],
                    [
                        "California",
                        98076
                    ],
                    [
                        "Florida",
                        4626
                    ],
                    [
                        "Alaska",
                        64221
                    ],
                    [
                        "Michigan",
                        1242
                    ],
                    [
                        "New York",
                        4069
                    ],
                    [
                        "Colorado",
                        3426
                    ],
                    [
                        "Illinois",
                        5020
                    ],
                    [
                        "North Carolina",
                        942
                    ],
                    [
                        "Virginia",
                        4802
                    ]
                ]
            },
            {
                "name": "Spirit",
                "id": "Spirit",
                "data": [
                    [
                        "Texas",
                        29087
                    ],
                    [
                        "California",
                        26629
                    ],
                    [
                        "Florida",
                        70483
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        19088
                    ],
                    [
                        "New York",
                        9294
                    ],
                    [
                        "Colorado",
                        7121
                    ],
                    [
                        "Illinois",
                        18742
                    ],
                    [
                        "North Carolina",
                        198
                    ],
                    [
                        "Virginia",
                        522
                    ]
                ]
            },
            {
                "name": "Republic",
                "id": "Republic",
                "data": [
                    [
                        "Texas",
                        20332
                    ],
                    [
                        "California",
                        0
                    ],
                    [
                        "Florida",
                        18657
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        8878
                    ],
                    [
                        "New York",
                        40125
                    ],
                    [
                        "Colorado",
                        4550
                    ],
                    [
                        "Illinois",
                        16232
                    ],
                    [
                        "North Carolina",
                        15939
                    ],
                    [
                        "Virginia",
                        32743
                    ]
                ]
            },
            {
                "name": "Envoy",
                "id": "Envoy",
                "data": [
                    [
                        "Texas",
                        62247
                    ],
                    [
                        "California",
                        0
                    ],
                    [
                        "Florida",
                        15385
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        6203
                    ],
                    [
                        "New York",
                        23477
                    ],
                    [
                        "Colorado",
                        1000
                    ],
                    [
                        "Illinois",
                        59634
                    ],
                    [
                        "North Carolina",
                        9946
                    ],
                    [
                        "Virginia",
                        7213
                    ]
                ]
            },
            {
                "name": "PSA",
                "id": "PSA",
                "data": [
                    [
                        "Texas",
                        234
                    ],
                    [
                        "California",
                        0
                    ],
                    [
                        "Florida",
                        9403
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        2307
                    ],
                    [
                        "New York",
                        7454
                    ],
                    [
                        "Colorado",
                        0
                    ],
                    [
                        "Illinois",
                        2738
                    ],
                    [
                        "North Carolina",
                        104619
                    ],
                    [
                        "Virginia",
                        32926
                    ]
                ]
            },
            {
                "name": "Endeavor",
                "id": "Endeavor",
                "data": [
                    [
                        "Texas",
                        4842
                    ],
                    [
                        "California",
                        0
                    ],
                    [
                        "Florida",
                        5331
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        20133
                    ],
                    [
                        "New York",
                        58208
                    ],
                    [
                        "Colorado",
                        28
                    ],
                    [
                        "Illinois",
                        2827
                    ],
                    [
                        "North Carolina",
                        12686
                    ],
                    [
                        "Virginia",
                        8996
                    ]
                ]
            },
            {
                "name": "Frontier",
                "id": "Frontier",
                "data": [
                    [
                        "Texas",
                        11380
                    ],
                    [
                        "California",
                        12573
                    ],
                    [
                        "Florida",
                        35100
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        2556
                    ],
                    [
                        "New York",
                        5285
                    ],
                    [
                        "Colorado",
                        45532
                    ],
                    [
                        "Illinois",
                        5716
                    ],
                    [
                        "North Carolina",
                        5514
                    ],
                    [
                        "Virginia",
                        4348
                    ]
                ]
            },
            {
                "name": "Mesa",
                "id": "Mesa",
                "data": [
                    [
                        "Texas",
                        80297
                    ],
                    [
                        "California",
                        9045
                    ],
                    [
                        "Florida",
                        3170
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        2276
                    ],
                    [
                        "New York",
                        2830
                    ],
                    [
                        "Colorado",
                        2384
                    ],
                    [
                        "Illinois",
                        1803
                    ],
                    [
                        "North Carolina",
                        2942
                    ],
                    [
                        "Virginia",
                        23448
                    ]
                ]
            },
            {
                "name": "Hawaiian",
                "id": "Hawaiian",
                "data": [
                    [
                        "Texas",
                        0
                    ],
                    [
                        "California",
                        9913
                    ],
                    [
                        "Florida",
                        0
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        0
                    ],
                    [
                        "New York",
                        693
                    ],
                    [
                        "Colorado",
                        0
                    ],
                    [
                        "Illinois",
                        0
                    ],
                    [
                        "North Carolina",
                        0
                    ],
                    [
                        "Virginia",
                        0
                    
                    ]
                ]
            },
            {
                "name": "Virgin",
                "id": "Virgin",
                "data": [
                    [
                        "Texas",
                        5684
                    ],
                    [
                        "California",
                        49695
                    ],
                    [
                        "Florida",
                        2540
                    ],
                    [
                        "Alaska",
                        0
                    ],
                    [
                        "Michigan",
                        0
                    ],
                    [
                        "New York",
                        6107
                    ],
                    [
                        "Colorado",
                        1215
                    ],
                    [
                        "Illinois",
                        1713
                    ],
                    [
                        "North Carolina",
                        164
                    ],
                    [
                        "Virginia",
                        3497
                    ]
                ]
            }
        ]
    }
});