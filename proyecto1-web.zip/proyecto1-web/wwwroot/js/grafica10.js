window.chart1 = new Highcharts.chart('container10', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Tiempo en el aire de cada aerolínea respecto a la distancia recorrida total'
    }, 
    credits: {
        enabled: false
    },
    xAxis: {
        categories: [
            'Grupo 1',
            'Grupo 2',
            'Grupo 3',
            'Grupo 4',
            'Grupo 5',
            'Grupo 6',
            'Grupo 7',
            'Grupo 8',
            'Grupo 9',
            'Grupo 10',
            'Grupo 11'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        max: 8000000,
        title: {
            text: 'Tiempo en el aire acumulado (minutos)'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.0f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Allegiant Air',
        data: [105, 585471, 2000750, 3001390, 3085820, 940982, 609886, 121235,0,0,0],
        color: '#f76c6c'

    }, {
        name: 'Hawaiian Airlines Inc.',
        data: [3331268, 62080,0,0,0,0,0,0,0, 3423027, 6740616],
        color: '#f99797'

    }, {
        name: 'PSA Airlines Inc.',
        data: [2895698, 6301555, 4514690, 1894394, 66073, 16010, 609886, 0,0,0,0],
        color: '#23305e'

    }, {
        name: 'Mesa Airlines Inc.',
        data: [972885,4565296,4789459,2199722,2122559,984255,74222,0,0,0,0],
        color: '#a8d0e6'

    }, {
        name: 'Endeavor Air Inc.',
        data: [1951695,4805198,4652937,2703585,1843842,259586,0,0,0,0,0],
        color: '#39424e'

    }]
});