window.chart1 = new Highcharts.chart('container7', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Crecimiento a lo largo del año'
    }, 
    credits: {
        enabled: false
    },
    xAxis: {
        categories: [
            'AS',
            'VX',
            'YV',
            'F9',
            'UA',
            'OO',
            'MQ',
            'HA',
            'DL',
            '9E',
            'NK',
            'G4',
            'OH',
            'YX',
            'WN',
            'AA',
            'B6',
            'EV'
        ],
        crosshair: true
    },
    yAxis: {
        min: -17,
        max: 15,
        title: {
            text: 'Crecimiento porcentual'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.3f}% </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: '2017',
        data: [1.85, 11.10, 3.06, 0.65, 0.92, 0.84, 3.18, 0.93, 1.12, 4.07, 1.25, 5.06, 3.74, 4.07, 0.88, 1.06, 1.20, 6.19],
        color: '#ffff40'

    }, {
        name: '2018',
        data: [1.11, -14.44, -4.11, -0.93, -1.38, -2.67, -6.34, -3.54, -3.85, -8.10, -4.78, -10.53, -8.78, -9.24, -5.03, -5.45, -6.10, -16.41],
        color: '#a2231d'

    }, {
        name: '2019',
        data: [1.53, 0.15, -0.011, -0.024, -0.063, -0.66, -0.89, -0.98, -1.011, -1.14, -1.33, -1.62, -1.62, -1.63, -1.65, -1.72, -1.92, -3.49],
        color: '#7aeee0'

    }]
});