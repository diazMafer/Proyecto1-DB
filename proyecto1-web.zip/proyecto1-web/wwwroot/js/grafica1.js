var chart = Highcharts.chart('container1', {

    title: {
        text: 'Aerolíneas con menor cantidad de vuelos cancelos'
    },

    subtitle: {
        text: '2017-2018'
    },
    credits: {
        enabled: false
    },
    xAxis: {
        categories: ['9E', 'G4', 'VX', 'HA', 'OO', 'UA', 'MQ', 'AS', 'F9', 'YX', 'YV', 'NK','EV','B6','DL','OH','AA','WN']
    },
    yAxis: {
      max: 10000,
      min: 0,
      title: {
        text: 'Cantidad de vuelos cancelados'
      }
    },
    series: [{
        type: 'column',
        colorByPoint: true,
        data: [318, 398, 433, 453, 1388, 1530, 1636, 1648, 1793, 1883, 2313, 2450, 2624, 3262, 3427, 4561, 6919, 9653],
        showInLegend: false
    }]

});

