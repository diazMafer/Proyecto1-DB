Highcharts.chart('container8', {

    title: {
        text: 'Aerolíneas con menor cantidad de vuelos por cuarto'
    },
    credits: {
        enabled: false
    },
    xAxis: {
        categories: ['9E', 'G4', 'VX', 'HA', 'OO', 'UA', 'MQ', 'AS', 'F9', 'YX', 'YV', 'NK','EV','B6','DL','OH','AA','WN']
    },
    yAxis: {
      max: 750000,
      min: 0,
      title: {
        text: 'Cantidad de vuelos cancelados'
      }
    },
    series: [{
        type: 'column',
        colorByPoint: true,
        data: [56306, 22137, 22332, 39372, 356783, 290752, 67601, 103008, 53545, 72612, 49140, 79855, 133335, 145444, 452897, 63849, 437009, 647093],
        showInLegend: false
    }]

});