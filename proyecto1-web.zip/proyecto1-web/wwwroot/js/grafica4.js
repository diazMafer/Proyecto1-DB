// Make monochrome colors
// Radialize the colors
Highcharts.setOptions({
    colors: Highcharts.map(Highcharts.getOptions().colors, function (color) {
        return {
            radialGradient: {
                cx: 0.5,
                cy: 0.3,
                r: 0.7
            },
            stops: [
                [0, color],
                [1, Highcharts.Color(color).brighten(-0.3).get('rgb')] // darken
            ]
        };
    })
});

// Build the chart
Highcharts.chart('container4', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Aportación porcentual al tiempo de retraso'
    },
    credits: {
        enabled: false
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.y:.4f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y:.4f}%',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                },
                connectorColor: 'silver'
            }
        }
    },
    series: [{
        name: 'Retraso',
        data: [
            { name: 'Southwest Co.', y: 16.2464 },
            { name: 'American Inc.', y: 0.9832 },
            { name: 'Skywest Inc.', y: 15.1635 },
            { name: 'Delta Inc.', y: 13.5398 },
            { name: 'United Inc.', y: 7.6378 },
            { name: 'JetBlue Airways', y: 7.1871 },
            { name: 'ExpressJet Inc.', y: 7.2728 },
            { name: 'Spirit', y: 1.8619 },
            { name: 'Frontier Inc.', y: 2.1842 },
            { name: 'PSA Inc.', y: 2.0880 },
            { name: 'Alaska Inc.', y: 1.9666 },
            { name: 'Republic Airline', y: 1.6567 },
            { name: 'Envoy Air', y: 1.5959 },
            { name: 'Endeavor Air', y: 1.7877 },
            { name: 'Mesa Inc.', y: 2.1137 },
            { name: 'Allegiant Air', y: 1.2275 },
            { name: 'Virgin America', y: 0.5445 },
            { name: 'Hawaiian Inc.', y: 0.9832 },
            
        ]
    }]
});