Highcharts.chart('container2', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Vuelos que salen a tiempo y llegan antes'
    }, 
    credits: {
        enabled: false
    },
    xAxis: {
        categories: [
            'WN',
            'DL',
            'AA',
            'UA',
            'OO',
            'B6',
            'EV',
            'OH',
            'NK',
            'AS',
            'MQ',
            'YV',
            'YX',
            'F9',
            'G4',
            'HA',
            'VX',
            '9E'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        max: 80000,
        title: {
            text: 'Cantidad de vuelo'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.0f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: '2017',
        data: [76667, 46464, 25723, 19252, 13086, 6854, 6004, 0, 3462, 3457, 0, 0, 0, 2996, 0, 1419, 1529, 0],
        color: '#c73636'

    }, {
        name: '2018',
        data: [77946, 42483, 2338, 15319, 12903, 5637, 2943, 8716, 4642, 4254, 6123, 5564, 5554, 2519, 5051, 1433, 336, 998],
        color: '#f16161bb'

    }]
});