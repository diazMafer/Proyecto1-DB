var chart = Highcharts.chart('container3', {

    title: {
        text: 'Total en horas de tiempo de adelanto'
    },

    subtitle: {
        text: '2017-2018'
    },
    credits: {
        enabled: false
    },
    xAxis: {
        categories: [
            'WN',
            'DL',
            'AA',
            'UA',
            'OO',
            'B6',
            'EV',
            'OH',
            'NK',
            'AS',
            'MQ',
            'YV',
            'YX',
            'F9',
            'G4',
            'HA',
            'VX',
            '9E'
        ]
    },
    yAxis: {
      max: 26000,
      min: 0,
      title: {
        text: 'Horas'
      }
    },
    series: [{
        type: 'column',
        colorByPoint: true,
        data: [25026, 18370, 9237, 6836, 4186, 2574, 1508, 1306, 1424, 1589, 916, 819, 1039, 1097, 705, 320, 393, 182],
        showInLegend: false
    }]

});